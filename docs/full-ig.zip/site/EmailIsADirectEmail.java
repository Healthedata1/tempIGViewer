package http://hl7.org/fhir/us/core/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class EmailIsADirectEmail {

}
