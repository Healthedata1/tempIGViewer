package http://hl7.org/fhir/ig/vhdir/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class Practitionerqualification {

}
